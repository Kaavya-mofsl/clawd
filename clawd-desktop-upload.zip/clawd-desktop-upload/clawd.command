#!/bin/bash
# Login-item wrapper: System Settings -> General -> Login Items -> "+".
#
# Guards against a second copy — macOS re-runs login items on fast user switching,
# and two Clawds means two pets per account stacked on the same spot.
#
# Match on the install path, not "electron": the real argv is
#   .../clawd-desktop/node_modules/electron/dist/Electron.app/Contents/MacOS/Electron .
# so a pattern like "electron .*clawd-desktop" matches nothing and the guard silently
# does the exact thing it exists to prevent.
cd "$(dirname "$0")" || exit 0
pgrep -f "clawd-desktop/node_modules/electron" >/dev/null 2>&1 && exit 0
./node_modules/.bin/electron . >/dev/null 2>&1 &
